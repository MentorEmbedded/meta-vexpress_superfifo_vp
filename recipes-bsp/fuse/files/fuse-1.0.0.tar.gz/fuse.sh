#!/bin/sh

echo "Mounting Host"
mkdir -p /host
fuse_host_access.exe /host



