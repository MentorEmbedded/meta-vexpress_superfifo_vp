#define TRACEPOINT_CREATE_PROBES

#include "superfifo_component_provider.h"
