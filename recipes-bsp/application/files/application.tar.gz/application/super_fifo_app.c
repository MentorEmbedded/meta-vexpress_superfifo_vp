#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <assert.h>
#include <string.h> // for memset and strlen

#include "mb/sw/control.h"
#include "super_fifo_ctrl.h"

#define TRACEPOINT_DEFINE
#include "superfifo_component_provider.h"


int main(int argc ,char *argv[])
{
        int status;

        mb_set_tlm_mode(MB_TLM_AT_MODE);

	int fp = open("/dev/superFIFODev", O_RDWR);

        printf("fp=%d\n", fp);
        if (fp < 0)
                perror("cannot open: ");
	
        status = ioctl(fp, SUPER_FIFO_IOC_CLEAR, 1);
        printf("status=%d\n", status);
        if (status < 0)
                perror("cannot ioctl: ");

        status = ioctl(fp, SUPER_FIFO_IOC_GET_STATUS, 0xffffffff);
        printf("status=%d\n", status);

        status = ioctl(fp, SUPER_FIFO_IOC_GET_COUNT, 1024);
        printf("status=%d\n", status);

        //some read write operation .
        char *buff = "Hello World! SuperFIFO";
        char res_buff[23];
        memset(res_buff, 0, 10);
        tracepoint(super_fifo_component, message, "Write Start");
        write(fp, buff, 10);
        tracepoint(super_fifo_component, message, "Write End");
        usleep(1000000);
        tracepoint(super_fifo_component, message, "Read Start");
        read(fp, res_buff, 10);
        tracepoint(super_fifo_component, message, "Read End");
        usleep(1000000);
        if(strncmp(buff, res_buff, 10) != 0)
          printf("TEST FAILED !!!!!! res_buff = %s\n", res_buff);

  
        //test larger than the FIFO size.

        memset(res_buff, 0, 23);
        tracepoint(super_fifo_component, message, "Write Start");
        write(fp, buff, 23);
        tracepoint(super_fifo_component, message, "Write End");
        usleep(10000);
        tracepoint(super_fifo_component, message, "Read Start");
        read(fp, res_buff, 17);
        tracepoint(super_fifo_component, message, "Read End");
        usleep(10000);
        if(strncmp(res_buff, "Hello World! Sup ", 16) != 0)
          printf("TEST FAILED !!!!!!\n");

        // write to fill the FIFO
        tracepoint(super_fifo_component, message, "Write Start");
        write(fp, buff, 23);
        tracepoint(super_fifo_component, message, "Write End");
        usleep(10000);
        int written = write(fp, buff, 23);
        if (written != 16) {
          printf("Clearing because FIFO is full.\n");
          status = ioctl(fp, SUPER_FIFO_IOC_CLEAR, 1);          
        }
        tracepoint(super_fifo_component, message, "Write Start");
        write(fp, buff, 23);
        tracepoint(super_fifo_component, message, "Write End");
        usleep(10000);
        tracepoint(super_fifo_component, message, "Read Start");
        int read_b = read(fp, res_buff, 17);
        tracepoint(super_fifo_component, message, "Read End");
        usleep(10000);
        if(read_b != 16)
          printf("TEST FAILED !!!!!!\n");

        if(strncmp(buff, res_buff, 16) != 0)
          printf("TEST FAILED !!!!!!\n");
        

        // two writes before read.
        tracepoint(super_fifo_component, message, "Write Start");
        write(fp, buff, 6);
        tracepoint(super_fifo_component, message, "Write End");
        usleep(10000);
        tracepoint(super_fifo_component, message, "Write Start");
        write(fp, buff, 23); // no matter the 23 it will write only 10 of them. you can check the return value
        tracepoint(super_fifo_component, message, "Write End");
        usleep(10000);
        tracepoint(super_fifo_component, message, "Read Start");
        read(fp, res_buff, 20); // no matter the 20 it will read only 16. you can check the return value
        tracepoint(super_fifo_component, message, "Read End");
        usleep(10000);
        if(strncmp(res_buff, "Hello Hello Worl", 16) != 0)
          printf("TEST FAILED !!!!!!\n");
        
        mb_set_tlm_mode(MB_TLM_LT_MODE);        

        close(fp);
}
