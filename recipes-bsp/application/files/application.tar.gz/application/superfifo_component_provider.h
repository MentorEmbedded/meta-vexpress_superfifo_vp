
#undef TRACEPOINT_PROVIDER
#define TRACEPOINT_PROVIDER super_fifo_component


#undef TRACEPOINT_INCLUDE
#define TRACEPOINT_INCLUDE "./superfifo_component_provider.h"


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#if !defined(_SUPERFIFO_COMPONENT_PROVIDER_H) || defined(TRACEPOINT_HEADER_MULTI_READ)
#define _SUPERFIFO_COMPONENT_PROVIDER_H

#include <lttng/tracepoint.h> 


TRACEPOINT_EVENT(
	super_fifo_component,
	message,
	TP_ARGS(char *, text),
	TP_FIELDS(
		ctf_string(message, text)
	)
)

TRACEPOINT_LOGLEVEL(
	super_fifo_component, 
	message, 
	TRACE_WARNING)

#endif /* _SAMPLE_COMPONENT_PROVIDER_H */

#include <lttng/tracepoint-event.h>

#ifdef __cplusplus
}
#endif /* __cplusplus */

