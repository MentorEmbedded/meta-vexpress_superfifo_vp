/****************************************************************************
*
*			Copyright (c) 2010 Mentor Graphics Corp.
*
* PROPRIETARY RIGHTS of Mentor Graphics Corp. are involved in the
* subject matter of this material.  All manufacturing, reproduction,
* use, and sales rights pertaining to this subject matter are governed
* by the license agreement.  The recipient of this software implicitly
* accepts the terms of the license.
*
****************************************************************************/

#ifndef EFFPROF_H
#define EFFPROF_H

#define EFFPROF_DEFAULT			0
#define EFFPROF_WRAP_OFF		EFFPROF_DEFAULT
#define EFFPROF_WRAP_ON			(1<<0)
#define EFFPROF_UST_PURE		(1<<1)
#define EFFPROF_DUMP_DYNAMIC		0 /* deprecated */

#ifdef __cplusplus
extern "C" {
#endif

void effprof_init( const char* outputFileName, int effprofFlags ) __attribute__ ((no_instrument_function));
void effprof_close() __attribute__ ((no_instrument_function));

int effprof_isenabled() __attribute__ ((no_instrument_function));
void effprof_disable() __attribute__ ((no_instrument_function));
void effprof_enable() __attribute__ ((no_instrument_function));

#ifdef __cplusplus
} //extern "C"
#endif

#endif/*EFFPROF_H*/
