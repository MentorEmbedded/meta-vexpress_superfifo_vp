#define TRACEPOINT_CREATE_PROBES
#define TRACEPOINT_DEFINE
#include "superfifo_component_provider.h"
