#ifndef __demo_sfifo_h__
#define __demo_sfifo_h__ 1

extern int sfifo_test_init(void);
extern int sfifo_test_close(void);
extern int sfifo_test_xfer(int byte_cnt);

#endif // __demo_sfifo_h__
