#include <iostream>
#include <iomanip>
#include "effprof.h"
#include "demo-sfifo.hpp"
#include "superfifo_component_provider.h"

int main(void)
{
	int sfifo_test_cnt = 0;
	int sfifo_test_err = 0;

	effprof_init("/mnt/tmp/superfifo_demo/rv-sfifo.eff", EFFPROF_DEFAULT);

	if (sfifo_test_init())
	{
		++sfifo_test_cnt;

		if (sfifo_test_xfer(10) == 0)
			++sfifo_test_err;
	}

	std::cout << "12345   Super-FIFO loopback test passed ";
	std::cout << (sfifo_test_cnt - sfifo_test_err) << " of ";
	std::cout << sfifo_test_cnt << " tests" << std::endl;

	sfifo_test_close();
	effprof_close();

	return (sfifo_test_cnt == sfifo_test_err);
}
