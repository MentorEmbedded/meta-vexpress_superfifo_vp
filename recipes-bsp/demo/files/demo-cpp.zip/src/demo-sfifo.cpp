#include <iostream>
#include <iomanip>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <string.h> // for memset and strlen

#include "superfifo_component_provider.h"
#include "mb/sw/control.h"
#include "sfifo_ctrl.h"

#define MAX_XFER_SIZE	64

static int fp_sfifo;

int sfifo_test_init(void)
{
	int init_ok;

    tracepoint(super_fifo_component, message, "+INIT");

	std::cout << "sfifo_test_init" << std::endl;

	mb_set_tlm_mode(MB_TLM_AT_MODE);

	fp_sfifo = open("/dev/superFIFODev", O_RDWR);

	if (fp_sfifo < 0)
	{
		init_ok = 0;
		perror("cannot open: ");
	}
	else
	{
		int status;
		status = ioctl(fp_sfifo, SUPER_FIFO_IOC_CLEAR, 1);
		std::cout << "status " << status << std::endl;
		if (status < 0)
		{
			init_ok = 0;
			perror("cannot ioctl: ");
		}
		else
		{
			init_ok = 1;

			status = ioctl(fp_sfifo, SUPER_FIFO_IOC_GET_STATUS, 0xffffffff);
			std::cout << "status " << status << std::endl;

			status = ioctl(fp_sfifo, SUPER_FIFO_IOC_GET_COUNT, 1024);
			std::cout << "status " << status << std::endl;
		}
	}

    tracepoint(super_fifo_component, message, "-init");

	return init_ok;
}

int sfifo_test_close(void)
{
    tracepoint(super_fifo_component, message, "+CLOSE");

    std::cout << "sfifo_test_close" << std::endl;

	mb_set_tlm_mode(MB_TLM_LT_MODE);        

	close(fp_sfifo);

    tracepoint(super_fifo_component, message, "-close");

	return 1;
}

int sfifo_test_xfer(int byte_cnt)
{
	int result;

	char recv_buff[MAX_XFER_SIZE];
	char send_buff[MAX_XFER_SIZE] = "SuperFIFO Loopback Test Data";

    tracepoint(super_fifo_component, message, "+TEST");

	std::cout << "SFIFO test of " << byte_cnt << " bytes" << std::endl;

	memset(recv_buff, 0, byte_cnt);

	tracepoint(super_fifo_component, message, "+WRITE");

	write(fp_sfifo, send_buff, byte_cnt);

	tracepoint(super_fifo_component, message, "-write");
	tracepoint(super_fifo_component, message, "+READ");

	read(fp_sfifo, recv_buff, 10);

	tracepoint(super_fifo_component, message, "-read");

	if (strncmp(recv_buff, send_buff, byte_cnt) != 0)
	{
		std::cout << "LOOPBACK TEST FAILED!" << std::endl;
		std::cout << "  Sent:  " << send_buff << std::endl;
		std::cout << "  Recv:  " << recv_buff << std::endl;

		result = 0;
	}
	else
		result = 1;

	tracepoint(super_fifo_component, message, "-test");

	return result;
}
