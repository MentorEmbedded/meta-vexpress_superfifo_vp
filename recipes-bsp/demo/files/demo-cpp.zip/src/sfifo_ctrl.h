
#ifndef __super_fifo_ctrl_h__
#define __super_fifo_ctrl_h__

#include <linux/ioctl.h>

/*
 * Ioctl definitions
 */
 
/* Use 'a' as magic number */
#define SUPER_FIFO_IOC_MAGIC  'a'
 
#define SUPER_FIFO_IOC_CLEAR    _IO(SUPER_FIFO_IOC_MAGIC, 0)
 
#define SUPER_FIFO_IOC_GET_STATUS _IO(SUPER_FIFO_IOC_MAGIC,  1)
#define SUPER_FIFO_IOC_GET_COUNT  _IO(SUPER_FIFO_IOC_MAGIC,  2)

#endif
